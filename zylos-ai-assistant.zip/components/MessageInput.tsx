
import React, { useState } from 'react';
import { SendIcon } from './icons/SendIcon';

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="p-4 bg-slate-900/50 backdrop-blur-sm border-t border-slate-700">
      <form onSubmit={handleSubmit} className="flex items-center space-x-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask anything..."
          disabled={isLoading}
          className="flex-1 bg-slate-800 border border-slate-600 rounded-full py-3 px-5 text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-sky-500 focus:outline-none disabled:opacity-50 transition-shadow"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-sky-600 hover:bg-sky-500 disabled:bg-slate-700 disabled:cursor-not-allowed text-white rounded-full p-3 transition-colors focus:ring-2 focus:ring-sky-500 focus:outline-none"
          aria-label="Send message"
        >
          <SendIcon className="w-6 h-6" />
        </button>
      </form>
    </div>
  );
};
