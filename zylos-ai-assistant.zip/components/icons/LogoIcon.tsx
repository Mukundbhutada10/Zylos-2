
import React from 'react';

export const LogoIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg 
      className={className} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="100" height="100" rx="12" fill="#1e293b"/>
      <g stroke="silver" strokeWidth="3">
        {/* Outer Frame */}
        <rect x="4" y="4" width="92" height="92" rx="8" />
        <rect x="10" y="10" width="80" height="80" rx="4" />

        {/* Inner Z */}
        <path d="M25 25 H 75 L 25 75 H 75" stroke="white" strokeWidth="12" strokeLinejoin="round" strokeLinecap="round" />

        {/* Circuit lines - simplified */}
        <path d="M10 40 H 20 V 30 H 22" strokeWidth="2" />
        <path d="M10 60 H 20 V 70 H 22" strokeWidth="2" />
        <path d="M90 40 H 80 V 30 H 78" strokeWidth="2" />
        <path d="M90 60 H 80 V 70 H 78" strokeWidth="2" />
        <path d="M40 10 V 20 H 30" strokeWidth="2" />
        <path d="M60 10 V 20 H 70" strokeWidth="2" />
        <path d="M40 90 V 80 H 30" strokeWidth="2" />
        <path d="M60 90 V 80 H 70" strokeWidth="2" />
      </g>
    </svg>
  );
};
