
import React from 'react';
import { LogoIcon } from './icons/LogoIcon';

export const Header: React.FC = () => {
  return (
    <header className="p-4 bg-slate-900/50 backdrop-blur-sm border-b border-slate-700">
      <div className="max-w-4xl mx-auto flex items-center space-x-4">
        <LogoIcon className="w-10 h-10" />
        <h1 className="text-2xl font-bold text-slate-100 tracking-wide">
          Zylos AI
        </h1>
      </div>
    </header>
  );
};
