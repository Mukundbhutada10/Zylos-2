
import React from 'react';
import type { Message } from '../types';
import { LogoIcon } from './icons/LogoIcon';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-slate-700 flex-shrink-0 flex items-center justify-center">
            <LogoIcon className="w-6 h-6" />
        </div>
      )}
      <div
        className={`rounded-lg px-4 py-3 max-w-lg whitespace-pre-wrap ${
          isUser
            ? 'bg-sky-600 text-white'
            : 'bg-slate-700 text-slate-200'
        }`}
      >
        {message.text}
      </div>
    </div>
  );
};
