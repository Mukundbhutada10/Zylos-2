
import React, { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { ChatWindow } from './components/ChatWindow';
import { MessageInput } from './components/MessageInput';
import type { Message } from './types';
import { runQuery } from './services/geminiService';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: 'Hello! I am Zylos, your AI assistant for MUFASA. How can I help you today?',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendMessage = async (userInput: string) => {
    if (!userInput.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', text: userInput };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const modelResponse = await runQuery(userInput);
      const modelMessage: Message = { role: 'model', text: modelResponse };
      setMessages((prevMessages) => [...prevMessages, modelMessage]);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred.';
      setError(`Failed to get response: ${errorMessage}`);
      const errorMessageObj: Message = { role: 'model', text: `Sorry, I encountered an error: ${errorMessage}` };
      setMessages((prevMessages) => [...prevMessages, errorMessageObj]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen bg-slate-900 text-slate-200 flex flex-col font-sans">
      <Header />
      <div className="flex-1 flex flex-col max-w-4xl w-full mx-auto overflow-hidden">
        <ChatWindow messages={messages} isLoading={isLoading} />
        <MessageInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        {error && <p className="text-red-400 text-center text-sm p-2">{error}</p>}
      </div>
    </div>
  );
};

export default App;
